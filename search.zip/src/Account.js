import React from 'react'

export default function Account({name}) {
    return (
        <div>
            {name}
        </div>
    )
}
